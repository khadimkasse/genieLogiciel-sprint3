/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication_tp2_2;

import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author user
 */
public class JavaApplication_TP2_2 {
    /**
     * @param args the command line arguments
     */
    private static EntityManagerFactory emf;
    private static EntityManager em;
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        emf = Persistence.createEntityManagerFactory("nouveauTestPU");
        em = emf.createEntityManager(); //Cette query va recuperer ce qui est deja dans la classe TClient.NamedQueries

        Query query = em.createNamedQuery(TClient.NamedQueries.FIND_ALL); //recupere les resultats de FIND_ALL 
        List<TClient> resultList = query.getResultList(); // Stocke les resultats dans une liste
        
        for(int i=0; i<resultList.size(); i++){
            System.out.println(resultList.get(i)); //Affiche les elmts de la table avec les resultats de la requete
        }
        
        // Modification du prmeier elmt de la liste d'identifiant 1
        Query getClientById = em.createNamedQuery(TClient.NamedQueries.FIND_BY_ID);
        getClientById.setParameter("id", 1);
        List<TClient> correspondingListClient = getClientById.getResultList();// On recupere et on stocke dans une liste les resultats de FIND_ALL
        TClient correspondingClient = correspondingListClient.get(0);
        System.out.println("Retrieving client id 1");
        System.out.println(correspondingClient);
        
        //Modification d'un client
        Scanner sc = new Scanner(System.in);
        System.out.println("Set the new client's name");  
        correspondingClient.setNom(sc.nextLine());
        System.out.println("***********************First Modification***********************");
        System.out.println(correspondingClient); // /!\ Les modifications sont presentes sur l'instance de la base mais pas sur la base
        // a proprement parler, on va donc persister l'objet en base 
        
        //On persiste l'objet en base:
        em.getTransaction().begin();        
        sc = new Scanner(System.in);
        System.out.println("Reset the new client's name");  
        correspondingClient.setNom(sc.nextLine());
        System.out.println("***********************Second Modification***********************");
        System.out.println(correspondingClient);
        em.getTransaction().commit();// Les modifications devraient affecter l'objet en base.
        
        // Ajout d'un nouveau client en base
        em.getTransaction().begin();
        TClient clientToPersist = new TClient();
        clientToPersist.setId(Long.valueOf(11));
        clientToPersist.setNom("Margaux Johansen");
        clientToPersist.setVille("Cannes");
        em.persist(clientToPersist);
        em.getTransaction().commit();// Le client devrait etre bien persiste en base, bien penser a modifier la valeur de l'id avant de recompiler
        
    }
}
