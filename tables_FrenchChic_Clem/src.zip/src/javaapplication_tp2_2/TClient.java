/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication_tp2_2;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author user
 */
@Entity
@Table(name = "T_CLIENT")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TClient.findAll", query = "SELECT t FROM TClient t")
    , @NamedQuery(name = "TClient.findById", query = "SELECT t FROM TClient t WHERE t.id = :id")
    , @NamedQuery(name = "TClient.findByNom", query = "SELECT t FROM TClient t WHERE t.nom = :nom")
    , @NamedQuery(name = "TClient.findByVille", query = "SELECT t FROM TClient t WHERE t.ville = :ville")})
public class TClient implements Serializable {

    public static class NamedQueries{
        public static final String FIND_ALL = "TClient.findAll";
        public static final String FIND_BY_ID = "TClient.findById";
        public static final String FIND_BY_NOM = "TClient.findByNom";
        public static final String FIND_BY_VILLE = "TClient.findByVille";   
    }
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ID")
    private Long id;
    @Column(name = "NOM")
    private String nom;
    @Column(name = "VILLE")
    private String ville;

    public TClient() {
    }

    public TClient(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TClient)) {
            return false;
        }
        TClient other = (TClient) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "ID = " + id + " NOM = " + nom + " VILLE = " + ville;
    }
    
}

// Pour repondre a la question, on fabrique une classe java qui a le meme nom que la table par defaut. 
