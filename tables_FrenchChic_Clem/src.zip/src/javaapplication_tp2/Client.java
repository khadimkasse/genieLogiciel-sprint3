/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication_tp2;
import java.io.Serializable;
import javax.persistence.*;
/**
 *
 * @author user
 */
@Entity
@Table(name = "t_client")
public class Client implements Serializable {
    @Id
    @GeneratedValue
    private Long id;
    private String nom;
    private String ville;
    public Client(){}
    public String getNom(){
        return nom;
    }
    public void setNom(String n){
        nom=n;
    }
    public String getVille(){
        return ville;
    }
    public void setVille(String v){
        ville =v;
    }
}